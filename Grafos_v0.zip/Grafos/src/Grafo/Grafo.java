package Grafo;
import java.util.*;
/*@author os */
public class Grafo {
    private int vertices;
    private int aristas;
    private int [][]matrizAdyacencia;
    private int orden;
    private List<Integer> gradosVertices=new ArrayList<Integer>();
    private List<Arista> l_aristas=new ArrayList<Arista>(); //E
    private List<Vertice> l_vertices=new ArrayList<Vertice>();//V
    private List<Integer> camino=new ArrayList<>();
    
    //Obtenemos la expresión - se construye la matriz
    Grafo(String grafo){    
        convertirExpresion(grafo); //se obtienen las aristas y vertices
        this.orden=vertices;
        construirMatriz();
        obtenerGradosVertices();
        //crearListaAristas();
    }
    
    //Obtenemos la matriz - se obtiene la expresión
    Grafo(int [][]mA){
        this.matrizAdyacencia=mA;
        this.vertices=mA.length;
        this.orden=vertices;
        this.aristas=(orden*(orden-1))/2;
        obtenerGradosVertices();
    }
    
    public void conjuntoAristas(){
        Scanner sc=new Scanner(System.in);//pedir al usuario la lista de vertices
        for(int i=0; i<this.aristas; i++){
            System.out.print("e"+(i+1)+": ");
            int vi=sc.nextInt();
            System.out.print("e"+(i+1)+": ");
            int vj=sc.nextInt();
            Arista a=new Arista(vi, vj);
            System.out.println();
            l_aristas.add(a);
        }
    }
    
    public void obtener_verticesAdyacentes(){
        for(int i=0; i<matrizAdyacencia.length; i++){
            List<Integer> m_vertices=new ArrayList<Integer>();
            for(int j=0; j<matrizAdyacencia.length; j++){
                int valor=matrizAdyacencia[i][j];
                if(valor>0){//si es mayor de 1 quiere decir que tiene arista multiple
                    if(i!=j){ //si son iguales quiere decir que es un lazo 
                        m_vertices.add(j+1);
                    }
                }
            }
            int[] matriz=lista_a_matriz(m_vertices);
            Vertice v=new Vertice(matriz);
            imprimir(matriz);
            System.out.println();
            l_vertices.add(v);
        }
    }
    
    public int[] lista_a_matriz(List<Integer> lista){
        int[] matriz=new int[lista.size()];
        for(int i=0; i<lista.size(); i++){
            matriz[i]=lista.get(i);
        }
        return matriz;
    }
    
    public void imprimir(int[] m_v){
        for(int i=0; i<m_v.length;i++){
            System.out.print(m_v[i]+" ");
        }
    }
    
    /*public void crearListaAristas(){
        for(int i=0; i<matrizAdyacencia.length; i++){    
            for(int j=0; j<matrizAdyacencia.length; j++){
                if(matrizAdyacencia[i][j]==1){ //se crea una sola arista
                    Arista a=new Arista(i, j);
                    l_aristas.add(a);
                }else if(matrizAdyacencia[i][j]>1){ //se crean el numero de aristas igual al numero obtenido en la matriz
                    int num=matrizAdyacencia[i][j];
                    while(){
                        
                    }
                }
            }
        }
    }*/
    
    public void verificar_Econectividad(){
        
    }
    
    public void construirMatriz(){
        matrizAdyacencia=new int[vertices][vertices];
        conjuntoAristas();//obtener lista de aristas
        for(int i=0; i<l_aristas.size(); i++){ //recorrer la lista de aristas
            int vi=l_aristas.get(i).getVertice_i();
            int vf=l_aristas.get(i).getVertice_f();
            if(vi==vf){
                matrizAdyacencia[vi-1][vf-1]=matrizAdyacencia[vi-1][vf-1]+1;
            
            }else{
                matrizAdyacencia[vi-1][vf-1]=matrizAdyacencia[vi-1][vf-1]+1;
                matrizAdyacencia[vf-1][vi-1]=matrizAdyacencia[vf-1][vi-1]+1;
            }
            
        }
        for(int i=0; i<vertices; i++){
            for(int j=0; j<vertices; j++){
                System.out.print(matrizAdyacencia[i][j] +" ");
            }System.out.println();
        }
    }
    
    public void obtenerGradosVertices(){
        for(int i=0; i<matrizAdyacencia.length; i++){    
            int g_vertice=0;
            for(int j=0; j<matrizAdyacencia.length; j++){
                g_vertice=g_vertice+matrizAdyacencia[i][j];
            }
            gradosVertices.add(g_vertice);
            System.out.println("v"+(i+1)+": "+gradosVertices.get(i));
        }
    }
    
    public void convertirExpresion(String grafo){
        String expresion = grafo.substring(grafo.indexOf("(")+1, grafo.indexOf(")"));
        String[] partes = expresion.split(",");
        vertices = Integer.parseInt(partes[0]); 
        aristas = Integer.parseInt(partes[1]); 
        System.out.println("vertices: "+vertices+" aristas: "+aristas);
    }
}
