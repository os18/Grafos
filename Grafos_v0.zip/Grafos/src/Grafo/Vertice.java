package Grafo;
/*@author os*/
public class Vertice {
    int[] verticesAdyacentes;
    boolean visitado;

    public Vertice(int[] verticesAdyacentes) {
        this.verticesAdyacentes = verticesAdyacentes;
    }
    
    public int[] getVerticesAdyacentes() {
        return verticesAdyacentes;
    }

    public void setVerticesAdyacentes(int[] verticesAdyacentes) {
        this.verticesAdyacentes = verticesAdyacentes;
    }
}
