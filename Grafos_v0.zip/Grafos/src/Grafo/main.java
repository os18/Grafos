package Grafo;
/*@author os*/
public class main {
    public static void main(String args[]){
        String grafo="G=(6,12)";
        Grafo g=new Grafo(grafo);
        g.obtener_verticesAdyacentes();
        /*int[][] matrizA={{1,1,0,0,0,0},
                         {1,0,1,1,0,0},
                         {0,1,0,1,2,1},
                         {0,1,1,0,1,2},
                         {0,0,2,1,0,1},
                         {0,0,1,2,1,0}};
        Grafo g=new Grafo(matrizA);*/
    }
}