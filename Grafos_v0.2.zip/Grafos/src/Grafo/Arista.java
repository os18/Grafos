package Grafo;
/* @author os*/
public class Arista {
    private int vertice_i;
    private int vertice_f;

    public Arista(int vertice_i, int vertice_f) {
        this.vertice_i = vertice_i;
        this.vertice_f = vertice_f;
    }

    public int getVertice_i() {
        return vertice_i;
    }

    public void setVertice_i(int vertice_i) {
        this.vertice_i = vertice_i;
    }

    public int getVertice_f() {
        return vertice_f;
    }

    public void setVertice_f(int vertice_f) {
        this.vertice_f = vertice_f;
    }
}