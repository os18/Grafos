package Grafo;
import java.util.*;
/*@author os */
public class Grafo {
    private int vertices; //num_vertices
    private int aristas;  //num_aristas
    private int [][]matrizAdyacencia; 
    private int orden;    //n
    private List<Integer> gradosVertices=new ArrayList<Integer>();
    private List<Arista> l_aristas=new ArrayList<Arista>(); //E
    private List<Vertice> l_vertices=new ArrayList<Vertice>();//V
    private List<Integer> camino=new ArrayList<>();
    
    Grafo(String grafo){    //Obtenemos la expresión - se construye la matriz
        convertirExpresion(grafo); //se obtienen las aristas y vertices
        this.orden=vertices;
        construirMatriz();
        obtenerGradosVertices();
    }
    
    Grafo(int [][]mA){ //Obtenemos la matriz - se contruye la expresión
        this.matrizAdyacencia=mA;
        this.vertices=mA.length;
        this.orden=vertices;
        this.aristas=(orden*(orden-1))/2;
        obtenerGradosVertices();
    }
    
    public void conjuntoAristas(){
        Scanner sc=new Scanner(System.in);//pedir al usuario la lista de vertices
        for(int i=0; i<this.aristas; i++){
            System.out.print("e"+(i+1)+": ");
            int vi=sc.nextInt();
            System.out.print("e"+(i+1)+": ");
            int vj=sc.nextInt();
            Arista a=new Arista(vi, vj);
            System.out.println();
            l_aristas.add(a);
        }
    }
    
    public void obtener_verticesAdyacentes(){
        System.out.println("Vertices adyacentes: ");
        for(int i=0; i<matrizAdyacencia.length; i++){
            List<Integer> m_vertices=new ArrayList<Integer>();
            for(int j=0; j<matrizAdyacencia.length; j++){
                int valor=matrizAdyacencia[i][j];
                if(valor>0){//si es mayor de 1 quiere decir que tiene arista multiple
                    if(i!=j){ //si son iguales quiere decir que es un lazo 
                        m_vertices.add(j+1);
                    }
                }
            }
            Vertice v=new Vertice(m_vertices);
            System.out.print("v"+(i+1)+": ");
            imprimir(m_vertices);
            System.out.println();
            l_vertices.add(v);
        }
    }
    
    public void imprimir(List<Integer> m_v){
        for(int i=0; i<m_v.size(); i++){
            System.out.print(m_v.get(i)+" ");
        }
    }
    
    public void construirMatriz(){
        matrizAdyacencia=new int[vertices][vertices];
        conjuntoAristas();//obtener lista de aristas
        for(int i=0; i<l_aristas.size(); i++){ //recorrer la lista de aristas
            int vi=l_aristas.get(i).getVertice_i();
            int vf=l_aristas.get(i).getVertice_f();
            if(vi==vf){
                matrizAdyacencia[vi-1][vf-1]=matrizAdyacencia[vi-1][vf-1]+1;
            }else{
                matrizAdyacencia[vi-1][vf-1]=matrizAdyacencia[vi-1][vf-1]+1;
                matrizAdyacencia[vf-1][vi-1]=matrizAdyacencia[vf-1][vi-1]+1;
            }
        }
        System.out.println("Matriz adyacencia: ");
        for(int i=0; i<vertices; i++){
            for(int j=0; j<vertices; j++){
                System.out.print(matrizAdyacencia[i][j] +" ");
            }System.out.println();
        }
    }
    
    public void obtenerGradosVertices(){
        System.out.println("Grados de los vértices: ");
        for(int i=0; i<matrizAdyacencia.length; i++){    
            int g_vertice=0;
            for(int j=0; j<matrizAdyacencia.length; j++){
                g_vertice=g_vertice+matrizAdyacencia[i][j];
            }
            gradosVertices.add(g_vertice);
            System.out.println("v"+(i+1)+": "+gradosVertices.get(i));
        }
    }
    
    public void convertirExpresion(String grafo){
        String expresion = grafo.substring(grafo.indexOf("(")+1, grafo.indexOf(")"));
        String[] partes = expresion.split(",");
        vertices = Integer.parseInt(partes[0]); 
        aristas = Integer.parseInt(partes[1]); 
        System.out.println("vertices: "+vertices+" aristas: "+aristas);
    }
    
    /*public boolean Conexo(){
        boolean conexo=true;
        for(int i=1; i<=vertices; i++){
            if(l_vertices.get(i).isVisitado()==false){
                DFS_(i);
            }
        }
        
        if(l_vertices.size()!=camino.size()){
            conexo = false;
        }
        return conexo;
    }
    
    public void DFS_(int v){
        l_vertices.get(v).setVisitado(true);
        System.out.print((v)+ " ");
        camino.add(v);
        //revisar sus vertices adyacentes
        int num_VeAdy=l_vertices.get(v-1).getVerticesAdyacentes().size(); //cantidad de vertices adyacentes
        if(num_VeAdy!=0){ 
            for(int i=0; i<num_VeAdy; i++){
                int nV=l_vertices.get(v-1).getVerticesAdyacentes().get(i); //obteniendo los vertices adyacentes del vertice indicado
                if(l_vertices.get(nV).isVisitado()==false){ //si ese elemento no ha sido visitado, se visita
                    DFS_(nV);
                }
            }
        }else{ //no tiene vertices adyacentes
            System.out.println("No es conexo");
        }
        
    }*/
    
    public boolean Conexo(){
        boolean conexo=true;
        List<Integer> fila=new ArrayList<>();
        for(int i=0; i<matrizAdyacencia.length; i++){    
            for(int j=0; j<matrizAdyacencia.length; j++){
                fila.add(matrizAdyacencia[i][j]);
            }
            boolean aux=conexion(fila);
            if(aux==false){
                System.out.println("No es conexo");
                conexo=false;
                break;
            }
        }
        return conexo;
    }
    
    public boolean conexion(List<Integer> fila){
        boolean cnx=true;
        int c_ceros=0;
        for(int x=0; x<fila.size(); x++){
            if(fila.get(x)==0){
                c_ceros++;
            }
        }
        if(c_ceros==fila.size()){
            cnx=false;
        }
        return cnx;
    }
    
    public int verificar_E_conectividad(){
        int min = Collections.min(gradosVertices); 
        int e_conectividad = min;
        
        for(int i=0; i<gradosVertices.size(); i++){
            if(gradosVertices.get(i)==min){
                if(matrizAdyacencia[i][i]!=0){
                    e_conectividad=min-1;
                }
            }
        }
        return e_conectividad;
    }
}