package Grafo;
import java.util.List;

/*@author os*/
public class Vertice {
    List<Integer> verticesAdyacentes;
    boolean visitado;

    public Vertice(List<Integer> verticesAdyacentes) {
        this.verticesAdyacentes = verticesAdyacentes;
    }
    
    public List<Integer> getVerticesAdyacentes() {
        return verticesAdyacentes;
    }

    public void setVerticesAdyacentes(List<Integer> verticesAdyacentes) {
        this.verticesAdyacentes = verticesAdyacentes;
    }

    public boolean isVisitado() {
        return visitado;
    }

    public void setVisitado(boolean visitado) {
        this.visitado = visitado;
    }
}
